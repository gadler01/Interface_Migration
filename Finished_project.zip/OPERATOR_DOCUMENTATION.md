# NetBox Device & Interface JSON Migration Tool
## Operator Documentation

**Version:** 1.0 Advanced Edition  
**Last Updated:** May 2026  
**Status:** Production Ready

---

## Table of Contents

1. [Overview](#overview)
2. [Installation & Setup](#installation--setup)
3. [Quick Start](#quick-start)
4. [Export Operations](#export-operations)
5. [Import Operations](#import-operations)
6. [Monitoring & Logging](#monitoring--logging)
7. [Troubleshooting](#troubleshooting)
8. [Common Use Cases](#common-use-cases)
9. [Best Practices](#best-practices)
10. [Reference](#reference)

---

## Overview

The NetBox Device & Interface JSON Migration Tool enables you to:

✓ **Export** devices and interfaces from one NetBox site/location to JSON  
✓ **Filter** exports by device type, tags, or cable status  
✓ **Import** devices and interfaces to a different site/location  
✓ **Track** all operations with detailed logging  
✓ **Verify** accuracy with interface counts and summaries  

**Perfect for:**
- Disaster recovery replication
- Site migrations
- Testing and staging
- Infrastructure as Code (IaC)
- Bulk interface creation

---

## Installation & Setup

### Requirements

- Python 3.6+
- `requests` library
- NetBox instance with API access
- NetBox API token

### Step 1: Install Dependencies

```bash
# Create virtual environment (recommended)
python3 -m venv netbox_env
source netbox_env/bin/activate

# Install requests
pip install requests
```

### Step 2: Get API Token

1. Log into NetBox UI: `https://your-netbox:8000`
2. Navigate to **Admin** (bottom left) → **Users**
3. Click your username
4. Scroll to **Auth tokens** section
5. Click **Add token** or copy existing token
6. Copy the full token (includes `nbt_` prefix)

### Step 3: Configure Script

Edit `netbox_json_migration_advanced.py` and update:

```python
NETBOX_URL = "https://your-netbox:8000"
API_TOKEN = "nbt_YOUR_FULL_TOKEN_HERE"
VERIFY_SSL = True  # Set to False if using self-signed certs
```

### Step 4: Test Connection

```bash
python3 netbox_json_migration_advanced.py export --help
```

You should see the help menu without errors.

---

## Quick Start

### 5-Minute Overview

**Export all interfaces from a site:**
```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "" export.json
```

**Export only cabled interfaces:**
```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "" export_cabled.json --cabled
```

**Import to new site:**
```bash
python3 netbox_json_migration_advanced.py import export_cabled.json "LightEdge-Chaska" "DCI"
```

**Check the log file:**
```bash
# View latest log
cat netbox_migration_*.log
```

---

## Export Operations

### Export Command Syntax

```bash
python3 netbox_json_migration_advanced.py export <site> [location] [output_file] [options]
```

### Parameters

| Parameter | Required | Description | Example |
|-----------|----------|-------------|---------|
| `<site>` | Yes | NetBox site name or slug | `"DCI-OKC"` or `"dci"` |
| `[location]` | No | Specific location at site | `"Building-A"` or leave empty `""` |
| `[output_file]` | No | Output JSON filename | `export.json` (default: `export_SITE.json`) |

### Options

| Option | Description | Example |
|--------|-------------|---------|
| `--all` | Export all interfaces (default) | `export dci "" export.json --all` |
| `--cabled` | Export only interfaces with cables | `export dci "" export.json --cabled` |
| `--device-type NAME` | Filter by device type | `export dci "" export.json --device-type "Switch"` |
| `--tag NAME` | Filter by device tag | `export dci "" export.json --tag "production"` |

### Export Examples

#### Example 1: Export All Interfaces

```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "" export_all.json
```

**Output:**
```
======================================================================
EXPORT SUMMARY
======================================================================
File:                  export_all.json
Export Type:           all
Total Devices:         48
Total Interfaces:      1,234
Cabled Interfaces:     567
======================================================================
```

**Use this for:** Complete infrastructure replication, disaster recovery backups

#### Example 2: Export Only Cabled Interfaces

```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "" export_cabled.json --cabled
```

**Output:**
```
======================================================================
EXPORT SUMMARY
======================================================================
File:                  export_cabled.json
Export Type:           cabled
Total Devices:         48
Total Interfaces:      567
Cabled Interfaces:     567
======================================================================
```

**Use this for:** Production interfaces only, skip virtual/loopback interfaces

#### Example 3: Export Specific Device Type

```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "" export_switches.json --device-type "Switch"
```

**Output:**
```
======================================================================
EXPORT SUMMARY
======================================================================
File:                  export_switches.json
Export Type:           all
Device Type Filter:    Switch
Total Devices:         12
Total Interfaces:      456
Cabled Interfaces:     234
======================================================================
```

**Use this for:** Network switch migration, device replacement

#### Example 4: Export by Tag + Cabled Only

```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "" export_prod_cabled.json --tag "production" --cabled
```

**Use this for:** Production-only migrations, reduce clutter

#### Example 5: Export Specific Location

```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "Building-A/Floor-2" export_floor2.json
```

**Use this for:** Floor-by-floor migrations, location-specific backups

### What Gets Exported

✓ Device name, type, status, tags, location  
✓ All interface properties (type, MTU, description, mode)  
✓ VLAN assignments (tagged and untagged)  
✓ Cable attachment status  
✓ Enabled/disabled status  

✗ Device physical attributes (serial, asset tag)  
✗ MAC addresses  
✗ Cable routing/connections  
✗ Power information  

### Export File Structure

```json
{
  "source_site": "DCI-OKC",
  "source_location": null,
  "export_type": "cabled",
  "device_type_filter": null,
  "tag_filter": null,
  "export_date": "2026-05-03T12:34:56.123456",
  "summary": {
    "total_devices": 48,
    "total_interfaces": 567,
    "cabled_interfaces": 567
  },
  "devices": [
    {
      "id": 1,
      "name": "router-1",
      "site": "DCI-OKC",
      "location": null,
      "device_type": "Router Model X",
      "status": "Active",
      "tags": ["production", "critical"],
      "interface_count": 5,
      "cabled_count": 4,
      "interfaces": [
        {
          "id": 101,
          "name": "eth0",
          "type": "1000base-t",
          "enabled": true,
          "mtu": 1500,
          "description": "Uplink",
          "mode": "access",
          "has_cable": true,
          ...
        }
      ]
    }
  ]
}
```

---

## Import Operations

### Import Command Syntax

```bash
python3 netbox_json_migration_advanced.py import <json_file> <target_site> [target_location] [--connected]
```

### Parameters

| Parameter | Required | Description | Example |
|-----------|----------|-------------|---------|
| `<json_file>` | Yes | Exported JSON file | `export_cabled.json` |
| `<target_site>` | Yes | Destination site (name or slug) | `"LightEdge-Chaska"` or `"lightedge-chaska"` |
| `[target_location]` | No | Destination location | `"DCI"` |
| `[--connected]` | No | Only import cabled interfaces | `--connected` |

### Prerequisites for Import

**Before importing, you MUST:**

1. ✓ Devices must exist at target site with **same names**
2. ✓ Location must exist at target site (if importing to location)
3. ✓ VLANs must exist at target site
4. ✓ Interface names must not already exist on target devices

### Import Examples

#### Example 1: Basic Import

```bash
python3 netbox_json_migration_advanced.py import export_all.json "LightEdge-Chaska" "DCI"
```

**Output:**
```
============================================================
IMPORT SUMMARY
============================================================
Total:    1,234
Created:  1,100 ✓
Skipped:  100 ⊘
Failed:   34 ✗
============================================================
```

**What this does:**
- Creates 1,100 new interfaces on existing devices
- Skips 100 interfaces (already exist)
- Reports 34 failures (devices not found, VLANs missing, etc.)

#### Example 2: Import Only Cabled Interfaces

```bash
python3 netbox_json_migration_advanced.py import export_cabled.json "LightEdge-Chaska" "DCI" --connected
```

**Use this for:** Skip disconnected interfaces during import

#### Example 3: Import Without Location

```bash
python3 netbox_json_migration_advanced.py import export.json "LightEdge-Chaska"
```

**Use this for:** Site-level migration without location assignment

### Import Workflow

```
1. Export from source
   ↓
2. Verify export count
   ↓
3. Ensure target devices exist
   ↓
4. Ensure target VLANs exist
   ↓
5. Run import with --connected flag (optional)
   ↓
6. Review import summary
   ↓
7. Check log for failures
   ↓
8. Verify in NetBox UI
```

---

## Monitoring & Logging

### Log File Location

Log files are created in the working directory with timestamps:

```bash
netbox_migration_20260503_125430.log
```

### View Logs

```bash
# View latest log
tail -f netbox_migration_*.log

# View entire log
cat netbox_migration_20260503_125430.log

# Search log for errors
grep ERROR netbox_migration_*.log

# Search log for specific device
grep "router-1" netbox_migration_*.log
```

### Log Levels

| Level | Description | Example |
|-------|-------------|---------|
| INFO | Normal operation | `2026-05-03 12:34:56 - INFO - ✓ Connected to NetBox` |
| WARNING | Non-critical issues | `2026-05-03 12:34:57 - WARNING - VLAN not found: VLAN10` |
| ERROR | Critical failures | `2026-05-03 12:34:58 - ERROR - Device not found: router-1` |
| DEBUG | Detailed information | `2026-05-03 12:34:59 - DEBUG - Found location 'DCI': 1 results` |

### Key Log Entries to Monitor

```
✓ Connected to NetBox          → API connection successful
Found X devices               → Export started
X: Y interfaces              → Per-device interface count
Error fetching interfaces    → API connection problem
Device not found             → Target device missing
Location not found           → Target location missing
VLAN not found               → Target VLAN missing
Created X on Y               → Interface created successfully
Skipped (exists)             → Interface already exists
Failed to create X           → Interface creation failed
```

---

## Troubleshooting

### Issue: "Cannot connect to NetBox"

**Cause:** API token invalid or URL wrong

**Solution:**
1. Check NetBox URL: `https://your-netbox:8000` (must be HTTPS)
2. Verify API token in script (includes `nbt_` prefix)
3. Test token in browser: `https://your-netbox:8000/api/status/`
4. Check firewall/network access

```bash
# Test manually
curl -H "Authorization: Bearer nbt_YOUR_TOKEN" https://your-netbox:8000/api/status/
```

### Issue: "No devices found"

**Cause:** Site name incorrect or no devices at that site

**Solution:**
1. Check site name spelling (case-sensitive for search)
2. Use site slug instead: `dci` instead of `DCI-OKC`
3. Verify devices exist in NetBox UI
4. Check location filter (empty string `""` = all locations)

```bash
# Find exact site names
python3 -c "
import requests
resp = requests.get('https://your-netbox:8000/api/dcim/sites/', headers={'Authorization': 'Bearer nbt_TOKEN'}, verify=False)
for site in resp.json()['results']:
    print(f\"{site['name']} (slug: {site['slug']})\")"
```

### Issue: "Location not found"

**Cause:** Location doesn't exist at destination site

**Solution:**
1. Create location in NetBox first: Admin → Locations
2. Or leave location empty to skip location assignment
3. Or answer "yes" when prompted to continue anyway

### Issue: "Device not found at target site"

**Cause:** Devices don't exist at destination with same names

**Solution:**
1. Create devices at destination site first
2. Ensure device names match source exactly
3. Check spelling and case sensitivity

### Issue: "VLAN not found"

**Cause:** VLAN doesn't exist at target site

**Solution:**
1. Create VLAN at target site first: Admin → VLANs
2. Script warns but continues (interface created without VLAN)
3. Manually assign VLAN after import if needed

### Issue: Import says "0 created"

**Cause:** Interfaces already exist or devices not found

**Solution:**
1. Check log file for specific errors
2. Verify device names at target
3. Check if interfaces already exist in NetBox
4. Run import again with different devices

### Issue: SSL Certificate Error

**Cause:** Self-signed certificate on NetBox

**Solution:**
Set `VERIFY_SSL = False` in script:

```python
VERIFY_SSL = False  # For self-signed certs
```

---

## Common Use Cases

### Use Case 1: Disaster Recovery Replication

**Goal:** Create identical infrastructure at DR site

**Steps:**

1. **Export production:**
```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "" dr_backup.json --cabled
```

2. **Create devices at DR site** (manually or via script)

3. **Import to DR:**
```bash
python3 netbox_json_migration_advanced.py import dr_backup.json "DR-Site" "DCI"
```

4. **Verify:**
```bash
# Check counts match
grep "Total Interfaces" netbox_migration_*.log
```

---

### Use Case 2: Network Switch Replacement

**Goal:** Migrate interfaces from old switch to new switch

**Steps:**

1. **Export old switch:**
```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "" old_switch_export.json --device-type "Catalyst 6509"
```

2. **Manually rename devices in JSON:**
- Change `"name": "old-switch-1"` to `"name": "new-switch-1"`

3. **Import to new devices:**
```bash
python3 netbox_json_migration_advanced.py import old_switch_export.json "DCI-OKC" "DCI"
```

---

### Use Case 3: Production-Only Migration

**Goal:** Export and migrate only production interfaces

**Steps:**

1. **Tag devices as "production" in NetBox**

2. **Export production only:**
```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "" prod_export.json --tag "production" --cabled
```

3. **Import to staging/test:**
```bash
python3 netbox_json_migration_advanced.py import prod_export.json "Staging-Site" "Test-DCI"
```

---

### Use Case 4: Location-Specific Migration

**Goal:** Migrate all interfaces from one floor to another

**Steps:**

1. **Export specific floor:**
```bash
python3 netbox_json_migration_advanced.py export "DCI-OKC" "Building-A/Floor-2" floor2_export.json
```

2. **Import to new floor:**
```bash
python3 netbox_json_migration_advanced.py import floor2_export.json "DCI-OKC" "Building-B/Floor-3"
```

---

## Best Practices

### Before Export

✓ **Backup NetBox database** - Always have a backup before bulk operations  
✓ **Verify source devices** - Confirm all devices exist in NetBox UI  
✓ **Test on staging first** - Never run on production first time  
✓ **Check API token permissions** - Ensure token has read access  

### During Export

✓ **Review export summary** - Check device and interface counts  
✓ **Verify JSON file created** - `ls -lh export.json`  
✓ **Spot-check JSON content** - Open file and verify sample devices  

### Before Import

✓ **Create target devices** - All devices must exist first  
✓ **Create target VLANs** - All VLANs must exist first  
✓ **Create target locations** - If importing to specific location  
✓ **Verify interface names unique** - No duplicates at target  

### During Import

✓ **Use `--connected` flag** - Safer than importing all interfaces  
✓ **Review import summary** - Check created, skipped, failed counts  
✓ **Monitor log file** - Watch for error patterns  

### After Import

✓ **Verify in NetBox UI** - Spot-check sample devices  
✓ **Check interface counts** - Confirm all interfaces created  
✓ **Test connectivity** - Verify network still works  
✓ **Archive export/import logs** - Keep for audit trail  

---

## Reference

### Command Quick Reference

```bash
# Export all
export <site> "" export.json

# Export cabled only
export <site> "" export.json --cabled

# Export by type
export <site> "" export.json --device-type "Switch"

# Export by tag
export <site> "" export.json --tag "production"

# Export with multiple filters
export <site> "" export.json --device-type "Router" --tag "critical" --cabled

# Import basic
import export.json <target_site> <location>

# Import cabled only
import export.json <target_site> <location> --connected

# Import without location
import export.json <target_site>
```

### Export Summary Meaning

```
Total Devices:      Number of devices exported
Total Interfaces:   Number of interfaces in export
Cabled Interfaces:  Number with cables attached
```

### Import Summary Meaning

```
Total:   Total interfaces to import
Created: Successfully created ✓
Skipped: Already exist ⊘
Failed:  Errors during creation ✗
```

### File Naming Convention

```
export_SITENAME.json              # Default export name
export_cabled.json                # Cabled interfaces only
export_switches.json              # Device type filter
export_production.json            # Tag filter
netbox_migration_TIMESTAMP.log    # Log file (auto-generated)
```

### Site/Location Name Formats

```
Site can be:
- Display name: "DCI-OKC"
- Slug: "dci"

Location can be:
- Simple: "DCI"
- Hierarchical: "Building-A/Floor-2"
- Nested: "Facility/Building/Floor"
```

---

## Support & Escalation

### For Errors

1. **Check log file first** - Contains most detailed information
2. **Search log for ERROR** - Identify the root cause
3. **Try again with --cabled flag** - Often helps with problematic devices
4. **Reduce scope** - Export single device to test

### Common Error Messages

| Error | Meaning | Fix |
|-------|---------|-----|
| `403 Forbidden` | Bad API token | Regenerate token in NetBox |
| `400 Bad Request` | Invalid site name | Use correct site name/slug |
| `Device not found` | Device missing at target | Create device first |
| `VLAN not found` | VLAN missing at target | Create VLAN first |
| `Interface exists` | Already imported | Skip or use different device |

---

## Document History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | May 2026 | Initial release - Advanced filtering, cabled interfaces, summaries |

---

**For questions or issues, contact:** NetBox Administration  
**Last Updated:** May 3, 2026
